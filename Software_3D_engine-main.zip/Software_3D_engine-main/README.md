# Software_3D_engine
Python Software 3D Engine (Object Renderer) with Pygame, Numpy, Numba


![sofware_renderer](screenshots/0.png "sofware_renderer")
